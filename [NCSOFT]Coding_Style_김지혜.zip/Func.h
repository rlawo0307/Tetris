#pragma once

void File_Open(const std::string);
void Cursor_Move(int, int);


